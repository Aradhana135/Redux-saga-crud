import reducer from './users/reducer';

export {
    actionCreators,
    actionTypes,
    selector,
    NAME,
  } from './users/actions';
  export default reducer;